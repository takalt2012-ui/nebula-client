#version 130
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// lib/textures/noise.png 128x128: r white, g smooth (6 cells), b white, a flat
float hz_n2_q1(float x) {
    if (x <= 0.175920) return mix(0.117647, 0.341176, clamp((x - 0.029657) / 0.146263, 0.0, 1.0));
    if (x <= 0.263632) return mix(0.341176, 0.396078, clamp((x - 0.175920) / 0.087713, 0.0, 1.0));
    if (x <= 0.334068) return mix(0.396078, 0.435294, clamp((x - 0.263632) / 0.070436, 0.0, 1.0));
    if (x <= 0.382719) return mix(0.435294, 0.462745, clamp((x - 0.334068) / 0.048651, 0.0, 1.0));
    if (x <= 0.416061) return mix(0.462745, 0.490196, clamp((x - 0.382719) / 0.033342, 0.0, 1.0));
    if (x <= 0.444759) return mix(0.490196, 0.517647, clamp((x - 0.416061) / 0.028698, 0.0, 1.0));
    if (x <= 0.476041) return mix(0.517647, 0.541176, clamp((x - 0.444759) / 0.031282, 0.0, 1.0));
    if (x <= 0.506763) return mix(0.541176, 0.568627, clamp((x - 0.476041) / 0.030722, 0.0, 1.0));
    if (x <= 0.539518) return mix(0.568627, 0.588235, clamp((x - 0.506763) / 0.032756, 0.0, 1.0));
    if (x <= 0.573156) return mix(0.588235, 0.615686, clamp((x - 0.539518) / 0.033638, 0.0, 1.0));
    if (x <= 0.612074) return mix(0.615686, 0.639216, clamp((x - 0.573156) / 0.038918, 0.0, 1.0));
    if (x <= 0.647004) return mix(0.639216, 0.666667, clamp((x - 0.612074) / 0.034931, 0.0, 1.0));
    if (x <= 0.681810) return mix(0.666667, 0.698039, clamp((x - 0.647004) / 0.034806, 0.0, 1.0));
    if (x <= 0.718476) return mix(0.698039, 0.733333, clamp((x - 0.681810) / 0.036665, 0.0, 1.0));
    if (x <= 0.782474) return mix(0.733333, 0.784314, clamp((x - 0.718476) / 0.063998, 0.0, 1.0));
    if (x <= 0.924536) return mix(0.784314, 0.992157, clamp((x - 0.782474) / 0.142062, 0.0, 1.0));
    return 0.992157;
}
vec4 hz_n2_img(vec2 p) { return vec4(clamp(0.499065 + (hz_t3_hash(vec3(mod(floor(p * vec2(128.0, 128.0)), vec2(128.0, 128.0)), 17.000000)) - 0.5) * 1.000346, 0.000000, 1.000000), hz_n2_q1(hz_t3_noise(vec3(p, 0.0), 6.000000, 70.000000)), clamp(0.500001 + (hz_t3_hash(vec3(mod(floor(p * vec2(128.0, 128.0)), vec2(128.0, 128.0)), 123.000000)) - 0.5) * 1.003912, 0.000000, 1.000000), 1.000000); }
const ivec2 hz_n2_size = ivec2(128, 128);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif

#define VERTEX_SHADER
#define END
#define GBUFFERS_DAMAGEDBLOCK

#include "/program/gbuffers_damagedblock.glsl"
