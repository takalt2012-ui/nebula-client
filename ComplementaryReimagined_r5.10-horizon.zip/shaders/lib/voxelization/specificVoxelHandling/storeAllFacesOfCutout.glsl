doSolidBlockCheck = false;
storeToAllFaces = true;
